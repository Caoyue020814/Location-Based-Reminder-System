from LocationBasedReminderSystem.settings import admin_url_path
from LocationBasedReminderSystem.settings import SITE_NAME as site_name

from django.utils.html import format_html
from django.shortcuts import render, HttpResponse, reverse
import datetime
from django.db.models import Q


def base_context(request):
    try:
        SITE_NAME = site_name
        current_year = datetime.datetime.now().year
        return locals()
    except Exception as e:
        print('base_context error:{}'.format(e))
        return locals()

