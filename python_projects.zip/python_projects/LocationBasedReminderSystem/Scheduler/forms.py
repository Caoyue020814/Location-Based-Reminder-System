from django import forms
from .models import Scheduler
from django.forms import widgets
from django.core.exceptions import ValidationError
import re
# print([i.name for i in Scheduler._meta.get_fields()])


class SchedulerForm(forms.ModelForm):
    class Meta:
        model = Scheduler
        fields = ['session_key', 'message', 'destination', 'delayed_start', 'duration', 'termination']
        exclude = ['session_key', ]
        widgets = {
            Scheduler.message.field.name: widgets.Textarea(attrs={'class': 'form-control'}),
            Scheduler.destination.field.name: widgets.Select(attrs={'class': 'form-control select2'}),
            Scheduler.delayed_start.field.name: widgets.NumberInput(attrs={'class': 'form-control'}),
            Scheduler.duration.field.name: widgets.NumberInput(attrs={'class': 'form-control'}),
            Scheduler.termination.field.name: widgets.CheckboxInput(attrs={'class': ''}),
        }



