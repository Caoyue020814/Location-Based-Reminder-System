from django.contrib import admin
from .models import Scheduler
# Register your models here.


@admin.register(Scheduler)
class SchedulerAdmin(admin.ModelAdmin):
    print([i.name for i in Scheduler._meta.get_fields()])
    list_display = ['id', 'session_key', 'message', 'destination', 'create_update_time', 'delayed_start',
                    'static_delayed_start', 'duration', 'static_duration', 'termination']

    search_fields = ['id', 'session_key', 'message', 'destination__name', 'destination__classname', ]
    list_filter = ['create_update_time', 'static_delayed_start', 'static_duration', 'termination']
    raw_id_fields = ['destination']

