from django.shortcuts import render, redirect, reverse, HttpResponse
from libs.base_context import base_context
from Scheduler.models import Scheduler
from .forms import SchedulerForm
from geopy.distance import geodesic
from geopy import Point
from django.utils import timezone
from django.http import JsonResponse
# Create your views here.


def index(request):
    session_key = request.session.session_key
    print(session_key)
    if not session_key:
        request.session.save()
        session_key = request.session.session_key
    schedulers = Scheduler.objects.filter(session_key=session_key)
    print(schedulers)

    return render(request, 'index.html', {**base_context(request), **locals()})


def add(request):
    session_key = request.session.session_key
    print(session_key)
    if not session_key:
        request.session.save()
        session_key = request.session.session_key

    if request.method == 'GET':
        form = SchedulerForm()
        return render(request, 'add.html', {**base_context(request), **locals()})
    else:
        post = request.POST.copy()
        post.setdefault('session_key', session_key)
        form = SchedulerForm(data=post)
        if form.is_valid():
            new_obj = form.save()
            new_obj.session_key = session_key
            new_obj.save()
            return redirect(reverse('index'))

        return render(request, 'add.html', {**base_context(request), **locals()})

def edit(request, id):
    session_key = request.session.session_key
    print(session_key)
    if not session_key:
        request.session.save()
        session_key = request.session.session_key

    obj = Scheduler.objects.get(id=id, session_key=session_key)
    if request.method == 'GET':
        form = SchedulerForm(instance=obj)
        return render(request, 'add.html', {**base_context(request), **locals()})
    else:
        post = request.POST.copy()
        post.setdefault('session_key', session_key)
        form = SchedulerForm(data=post, instance=obj)
        if form.is_valid():
            form.save()
            return redirect(reverse('index'))

        return render(request, 'add.html', {**base_context(request), **locals()})


def remove(request, id):
    session_key = request.session.session_key
    print(session_key)
    if not session_key:
        request.session.save()
        session_key = request.session.session_key

    obj = Scheduler.objects.get(id=id, session_key=session_key)
    obj.delete()
    return redirect(reverse('index'))


def google_map(request):
    # print('ppppp')
    print(request.POST)
    latitude = request.POST['latitude']
    longitude = request.POST['longitude']

    now = timezone.now()
    # print(now)
    session_key = request.session.session_key
    # print(session_key)
    if not session_key:
        request.session.save()
        session_key = request.session.session_key

    user_place = Point(latitude, longitude)
    schedulers = Scheduler.objects.filter(session_key=session_key, termination=False)
    print(schedulers)
    if schedulers:
        for scheduler in schedulers:
            if scheduler.static_delayed_start:
                if scheduler.static_duration:
                    if scheduler.static_delayed_start <= now and scheduler.static_duration >= now:
                        print(0.00000)
                        pass
                    else:
                        print(111111)
                        continue
                else:
                    if scheduler.static_delayed_start <= now:
                        print(2222222222222)
                        pass
                    else:
                        print(33333)
                        continue
            elif scheduler.static_duration:
                if scheduler.static_duration <= now:
                    pass
                else:
                    continue
            destination_latitude = scheduler.destination.latitude
            destination_longitude = scheduler.destination.longitude
            destination_place = Point(destination_latitude, destination_longitude)
            distance = geodesic(user_place, destination_place).meters
            print(distance)
            if distance < 80:
                scheduler.termination = True
                scheduler.save()
                print('终结')
                string = f'message:{scheduler.message}'
                return HttpResponse(string)

    return HttpResponse('')


def display_map(request):
    session_key = request.session.session_key
    # print(session_key)
    if not session_key:
        request.session.save()
        session_key = request.session.session_key
    if request.method == "GET":
        return render(request, 'display_map.html', {**base_context(request), **locals()})
    else:
        datas = []
        schedulers = Scheduler.objects.filter(session_key=session_key, termination=False)

        for scheduler in schedulers:
            datas.append({'latitude': scheduler.destination.latitude, 'longitude': scheduler.destination.longitude})
        return JsonResponse(datas, safe=False)
