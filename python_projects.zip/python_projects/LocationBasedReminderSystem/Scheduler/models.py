from django.db import models
from CoordinateSystem.models import Coordinate
from django.utils import timezone
import datetime
# Create your models here.


class Scheduler(models.Model):
    session_key = models.CharField(verbose_name='Session Key')
    message = models.TextField(verbose_name='Message')
    destination = models.ForeignKey(to=Coordinate, verbose_name='Destination', on_delete=models.CASCADE)

    create_update_time = models.DateTimeField(editable=False, null=True, blank=True)
    delayed_start = models.FloatField(null=True, blank=True, verbose_name='Delayed start(second)')
    static_delayed_start = models.DateTimeField(editable=False, null=True, blank=True)#开始时间的绝对值
    duration = models.FloatField(null=True, blank=True, verbose_name='Duration(second)')
    static_duration = models.DateTimeField(editable=False, null=True, blank=True)#持续到某个时间，绝对值
    termination = models.BooleanField(default=False)

    def save(self, *args, **kwargs):
        self.create_update_time = timezone.now()
        self.static_delayed_start = None
        self.static_duration = None
        if self.delayed_start:
            self.static_delayed_start = self.create_update_time + datetime.timedelta(seconds=self.delayed_start)
        if self.duration:
            base_time = self.static_delayed_start if self.static_delayed_start else self.create_update_time
            self.static_duration = base_time + datetime.timedelta(seconds=self.duration)
        super().save(*args, **kwargs)



