/**
 * jeDate 演示
 */
    var enLang = {                            
        name  : "en",
        month : ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"],
        weeks : [ "SUN","MON","TUR","WED","THU","FRI","SAT" ],
        times : ["Hour","Minute","Second"],
        timetxt: ["Time","Start Time","End Time"],
        backtxt:"Back",
        clear : "Clear",
        today : "Now",
        yes   : "Confirm",
        close : "Close"
    }

    //区域范围选择

    jeDate("#date_range0",{
        format: "YYYY-MM-DD hh:mm:ss",
        multiPane:false,
        range:" 至 "
    });
    jeDate("#date_range1",{
        format: "YYYY-MM-DD hh:mm:ss",
        multiPane:false,
        range:" 至 "
    });
