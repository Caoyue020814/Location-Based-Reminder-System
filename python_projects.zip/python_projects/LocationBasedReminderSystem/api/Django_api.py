import os, sys, django
os.environ['DJANGO_SETTINGS_MODULE'] ='LocationBasedReminderSystem.settings'
this_path = os.path.abspath(os.path.dirname(__file__))
project_path = os.path.abspath(os.path.join(this_path, '..'))
sys.path.append(project_path)

def Load_Django():
    try:
        django.setup()
        return True
    except Exception as e:
        print('Load_Django:{}'.format(e))
        return False

if __name__ == '__main__':
    Load_Django()
    from CoordinateSystem.models import Coordinate
    import csv

    file = './Points of Interest 2023_12.csv'
    with open(file, 'r') as fp:
        reader = csv.reader(fp)

        line = 0
        for i in reader:
            if line == 0:
                line += 1
                continue
            name = i[0]
            classname = i[1]
            feature_easting = float(i[2])
            feature_northing = float(i[3])
            geographic_county = i[4]
            print(name, classname, type(feature_easting), type(feature_northing), geographic_county)
            Coordinate.objects.create(name=name, classname=classname, feature_northing=feature_northing,
                                      feature_easting=feature_easting, geographic_county=geographic_county)



