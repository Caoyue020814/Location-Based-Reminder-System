import os
current_path = os.path.abspath(os.path.dirname(__file__))
key = 'django-insecure-4vk$c*j(qjxz=p)f=b2fy(wjcx-0x*!rpc3diejtprfq25^bl$'
debug = True
hosts = ['*']
db = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'yc2022',
        'USER': 'yc2022',
        'PASSWORD': 'wnd4VKSANY3',
        'HOST': '132.145.18.149',
        'PORT': 5432,
    }

}

# db = {
#     'default': {
#         'ENGINE': 'django.db.backends.postgresql',
#         'NAME': 'LocationBasedReminderSystem',
#         'USER': 'LocationBasedReminderSystem',
#         'PASSWORD': 'JH48jkkfjsl40LKJH&*(4kl__))(e4hjh8%$RGHiZMNMs39ALPQ:744!~@#$%',
#         'HOST': '127.0.0.1',
#         'PORT': 5433,
#     }
#
# }
# return psycopg2.connect(
#         dbname='yc2022',
#         user='yc2022',
#         password='wnd4VKSANY3',
#         host='132.145.18.149'
#     )