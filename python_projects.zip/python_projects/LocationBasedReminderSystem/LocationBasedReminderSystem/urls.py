from django.contrib import admin
from django.urls import path, re_path, include
from django.views import static
from django.conf import settings
from .settings import DEBUG, static_token_str, media_token_str, admin_url_path, MEDIA_URL, MEDIA_ROOT
from Scheduler import views
from django.views.generic.base import RedirectView
from django.views.generic import TemplateView

urlpatterns = []
if not DEBUG:
    urlpatterns = [
        re_path(r'^' + static_token_str + '/(?P<path>.*)$', static.serve, {'document_root': settings.STATIC_ROOT},
                name='static'), ]

urlpatterns = urlpatterns + [
    re_path(r'^' + media_token_str + '/(?P<path>.*)$', static.serve, {'document_root': settings.MEDIA_ROOT},
            name='media'),
    re_path('^' + admin_url_path + '/', admin.site.urls),
    path('', views.index, name='index'),
    path('add/', views.add, name='add'),
    path('edit/<int:id>/', views.edit, name='edit'),
    path('remove/<int:id>/', views.remove, name='remove'),
    path('map/', views.google_map, name='google_map'),
    # path('get_position/', views.get_position, name='get_position'),
    path('display_map/', views.display_map, name='display_map'),
    re_path('.*', views.index, name='index'),

]
