from pathlib import Path
import os, sys
import time
from django.utils.safestring import mark_safe
from Config.config import *
BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = key
DEBUG = debug
ALLOWED_HOSTS = hosts
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'CoordinateSystem',
    'Scheduler',
    'sslserver',
]
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.locale.LocaleMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'LocationBasedReminderSystem.urls'
templates_folder = os.path.join(BASE_DIR, 'templates')
if not os.path.exists(templates_folder):
    os.makedirs(templates_folder)
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [templates_folder],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'django.template.context_processors.media',
            ],
        },
    },
]

WSGI_APPLICATION = 'LocationBasedReminderSystem.wsgi.application'
DATABASES = db
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'Europe/London'

USE_I18N = True

USE_L10N = True

USE_TZ = False

admin_url_path = 'admin'


DATA_UPLOAD_MAX_NUMBER_FIELDS = 10485760
media = 'media/'
media_token_str = 'uploads'
MEDIA_URL = '/' + media_token_str + '/'
MEDIA_ROOT = os.path.join(BASE_DIR, media)
if not os.path.exists(MEDIA_ROOT):
    os.makedirs(MEDIA_ROOT)

static = 'static/'
static_token_str = 'files'
STATIC_URL = '/'+static_token_str+'/'

if not DEBUG:
    STATIC_ROOT = os.path.join(BASE_DIR, static)
    real_static_path = STATIC_ROOT
else:
    STATICFILES_DIRS = [
        os.path.join(BASE_DIR, static),

    ]
    real_static_path = STATICFILES_DIRS[0]
if not os.path.exists(real_static_path):
    os.makedirs(real_static_path)
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
SESSION_ENGINE = 'django.contrib.sessions.backends.file'
SESSION_FILE_PATH = os.path.join(BASE_DIR, 'sessions_storage')
if not os.path.exists(SESSION_FILE_PATH):
    os.makedirs(SESSION_FILE_PATH)
SESSION_COOKIE_NAME = "sessionid"
# SESSION_COOKIE_PATH = "/"
# SESSION_COOKIE_DOMAIN = '.xxxxxx.cn'  # 　　　　# Session的cookie保存的域名  设置后admin必须在此域名下
# SESSION_COOKIE_SECURE = False
# SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_AGE = 31556927
# SESSION_EXPIRE_AT_BROWSER_CLOSE = False
# SESSION_SAVE_EVERY_REQUEST = False

SITE_NAME = 'Location Based Reminder System'






