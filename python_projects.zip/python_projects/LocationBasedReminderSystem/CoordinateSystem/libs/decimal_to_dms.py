
def coordinate_convert(latitude, longitude):
    def decimal_to_dms(decimal):
        degrees = int(decimal)
        minutes = int((decimal - degrees) * 60)
        seconds = (decimal - degrees - minutes / 60) * 3600
        return degrees, minutes, seconds

    latitude = latitude
    longitude = longitude

    lat_deg, lat_min, lat_sec = decimal_to_dms(latitude)
    lon_deg, lon_min, lon_sec = decimal_to_dms(abs(longitude))

    lat_direction = "N" if latitude >= 0 else "S"
    lon_direction = "E" if longitude >= 0 else "W"

    return f"{lat_deg}°{lat_min}'{lat_sec:.1f}\"{lat_direction}+{lon_deg}°{lon_min}'{lon_sec:.1f}\"{lon_direction}"


