# from geopy.distance import geodesic
#
# # 两个经纬度点
# point1 = (55.96003274343725, -3.1841048172521527)
# point2 = (51.5074, -0.1278)  # 纽约市的经纬度坐标
#
# # 计算两个点之间的距离
# distance = geodesic(point1, point2).kilometers
#
# print(f"The distance between the two points is {distance} kilometers.")


from geopy.distance import geodesic
from geopy import Point

# 两个经纬度点
point1 = Point(55.96736797687528, -3.2491365951589137)
point2 = Point(55.94830588437311, -3.195356494708751)

# 使用 Vincenty's formulae 计算距离
distance = geodesic(point1, point2).meters

print(f"The distance between the two points is {distance} meters.")