from django.contrib import admin
from .models import Coordinate
# Register your models here.


@admin.register(Coordinate)
class CoordinateAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'classname', 'feature_easting', 'feature_northing', 'geographic_county',
                    'latitude', 'longitude', 'google_map']

    search_fields = ['id', 'name', 'classname', 'feature_easting', 'feature_northing', 'geographic_county', 'longitude',
                    'latitude', ]

    list_filter = ['classname', ]




