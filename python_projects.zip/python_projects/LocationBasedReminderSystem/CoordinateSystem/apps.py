from django.apps import AppConfig


class CoordinatesystemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'CoordinateSystem'
    verbose_name = 'Coordinate System'
