from django.db import models
from pyproj import Proj, transform
from .libs.decimal_to_dms import coordinate_convert
from django.utils.html import format_html
# Create your models here.

class Coordinate(models.Model):
    name = models.CharField(max_length=255)
    classname = models.CharField(max_length=255)
    feature_easting = models.FloatField(null=True, blank=True)
    feature_northing = models.FloatField(null=True, blank=True)
    geographic_county = models.CharField(max_length=255)
    longitude = models.FloatField(null=True, blank=True)  # 经度
    latitude = models.FloatField(null=True, blank=True)  # 纬度

    def google_map(self):
        if self.latitude and self.longitude:
            # return format_html('<a target="_blank" href="https://www.google.com/maps/place/{}/@{},{},19z/">Google Map</a>', coordinate_convert(self.latitude, self.longitude), round(self.latitude, 7), round(self.longitude, 7))
            return format_html('<a target="_blank" href="https://www.google.com/maps/place/{}/@{},{},51m/data=!3m1!1e3">Google Map</a>', coordinate_convert(self.latitude, self.longitude), round(self.latitude, 7), round(self.longitude, 7))
        else:
            return ''

    @staticmethod
    def epsg27700_2_epsg4326(feature_easting, feature_northing):
        # 定义原始投影坐标系统和目标投影坐标系统
        osgb = Proj(init='epsg:27700')  # 英国国家网格坐标系
        wgs84 = Proj(init='epsg:4326')  # WGS84坐标系，即经纬度坐标

        # 转换坐标
        longitude, latitude = transform(osgb, wgs84, feature_easting, feature_northing)
        return longitude, latitude

    def save(self, *args, **kwargs):
        if self.feature_northing and self.feature_easting:
            longitude, latitude = self.epsg27700_2_epsg4326(self.feature_easting, self.feature_northing)
            self.longitude = longitude
            self.latitude = latitude
        super().save(*args, **kwargs)

    def __str__(self):
        return f'{self.name}|{self.classname}|{self.longitude},{self.latitude}'


